<?php
namespace Aws\DirectoryService\Exception;

use Aws\Exception\AwsException;

/**
 * AWS Directory Service Exception
 */
class DirectoryServiceException extends AwsException {}
