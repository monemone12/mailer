<?php

$config = array();

$config['api_key'] = '<your api key>';
$config['api_secret'] = '<your secret key>';

$config['minimum_balance'] = 50; // Minimum balance to be able to lend (bitfinex constant)